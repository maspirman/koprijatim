<div class="preloader" id="preloader">
    <div class="preloader-inner">
        <div class="loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>