 @if(!empty(get_static_option('preloader_status')))
    @include('frontend.partials.preloader.preloader-default')
@endif