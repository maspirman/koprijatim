<div class="ajax-preloader-wrap"></div>
<div class="autocomplete-search-data">
    <div class="account">
        <div id="show-autocomplete" style="display:none;">
            <ul class="autocomplete-warp"></ul>
        </div>
    </div>
</div>