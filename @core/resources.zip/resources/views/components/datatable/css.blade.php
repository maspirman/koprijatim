<link rel="stylesheet" href="{{asset('assets/backend/css/jquery.dataTables.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/responsive.bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/css/responsive.jqueryui.min.css')}}">

<style>
    .dataTables_wrapper .dataTables_paginate .paginate_button{
        padding: 0 !important;
    }
    div.dataTables_wrapper div.dataTables_length select {
        width: 60px;
        display: inline-block;
    }
    table.dataTable{
        width: 100% !important;
    }
</style>